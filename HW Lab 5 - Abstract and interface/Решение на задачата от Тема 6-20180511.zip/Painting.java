package citb406s2018week6;

public class Painting extends Goods {

    private int paintsQuantity;

    private double paintsPrice;

    public Painting(int paintsQuantity, double paintsPrice, double overCharge) {
        super(overCharge);
        this.paintsQuantity = paintsQuantity;
        this.paintsPrice = paintsPrice;
    }

    @Override
    public double totalCost() {
        System.out.println("Painting totalCost()");
        return paintsQuantity * paintsPrice;
    }

    @Override
    public String toString() {
        return super.toString() + "Painting{" + "paintsQuantity=" + paintsQuantity + ", paintsPrice=" + paintsPrice + '}';
    }

}
