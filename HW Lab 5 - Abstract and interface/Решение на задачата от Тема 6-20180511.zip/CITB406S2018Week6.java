/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citb406s2018week6;

/**
 *
 * @author Kostadinova
 */
public class CITB406S2018Week6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Goods good = new Vehicle(2, 2, 2);
        Vehicle vehicle1 = new Vehicle(1, 2, 3);
        Painting painting1 = new Painting(4, 5, 6);

        System.out.println(good.totalCost());
        System.out.println(vehicle1.toString());
        System.out.println(painting1.toString());

        System.out.println(vehicle1.totalCost());
        System.out.println(painting1.totalCost());

        System.out.println(vehicle1.salesPrice());
        System.out.println(painting1.salesPrice());

        Painting arrayOfPaintings[] = new Painting[5];

        for (int i = 0; i < 5; i++) {
            arrayOfPaintings[i] = new Painting(5, 4 * (i + 1), 3 * (i + 1) % 8);
        }

        Vehicle arrayOfVehicles[] = new Vehicle[3];

        for (int i = 0; i < 3; i++) {
            arrayOfVehicles[i] = new Vehicle(5, 4 * (i + 1), 3 * (i + 1) % 6);
        }

        Painter painter1 = new Painter(5);
        Engineer engineer1 = new Engineer(20, 50);

        for (Painting painting : arrayOfPaintings) {
            painter1.addPainting(painting);
        }

        for (Vehicle vehicle : arrayOfVehicles) {
            engineer1.addVehicle(vehicle);
        }

        System.out.println(painter1.totalEarnings());
        System.out.println(engineer1.totalEarnings());

    }

}
