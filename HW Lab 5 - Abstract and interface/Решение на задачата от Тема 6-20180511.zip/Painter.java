package citb406s2018week6;

public class Painter implements Creator {

    private int numberOfPaintingsSold;

    private Painting listOfPaintings[];

    public Painter(int numberOfPaintingsSold) {
        this.numberOfPaintingsSold = numberOfPaintingsSold;
        listOfPaintings = new Painting[numberOfPaintingsSold];
    }

    public int getNumberOfPaintingsSold() {
        return numberOfPaintingsSold;
    }

    public void setNumberOfPaintingsSold(int numberOfPaintingsSold) {
        this.numberOfPaintingsSold = numberOfPaintingsSold;
    }

    public void addPainting(Painting painting) {
        System.out.println("Adding painting to the array: " + painting.toString());
        Painting newListOfPaintings[];
        if (listOfPaintings != null) {
            newListOfPaintings = new Painting[listOfPaintings.length + 1];
            System.arraycopy(listOfPaintings, 0, newListOfPaintings, 0, listOfPaintings.length);
            newListOfPaintings[newListOfPaintings.length - 1] = painting;
        } else {
            newListOfPaintings = new Painting[1];
            newListOfPaintings[0] = painting;
        }
        listOfPaintings = newListOfPaintings;
    }

    @Override
    public double totalEarnings() {
        double totalEarnings = 0;
        for (Painting painting : listOfPaintings) {
            if (painting != null) {
                totalEarnings += painting.salesPrice();
            }
        }
        return totalEarnings;
    }

    @Override
    public void displayGoods() {
        for (Painting painting : listOfPaintings) {
            System.out.println(painting.toString());
            System.out.println(painting.totalCost());
            System.out.println(painting.salesPrice());

        }
    }
}
