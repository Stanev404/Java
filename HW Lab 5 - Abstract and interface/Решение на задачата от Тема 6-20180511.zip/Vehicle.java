package citb406s2018week6;

public class Vehicle extends Goods {

    private double materialsCost;

    private double honoraiumCost;

    public Vehicle(double materialsCost, double honoraiumCost, double overCharge) {
        super(overCharge);
        this.materialsCost = materialsCost;
        this.honoraiumCost = honoraiumCost;
    }

    @Override
    public double totalCost() {
        System.out.println("Vehicle totalCost()");
        return materialsCost + honoraiumCost;
    }

    @Override
    public String toString() {
        return super.toString() + "Vehicle{" + "materialsCost=" + materialsCost + ", honoraiumCost=" + honoraiumCost + '}';
    }

}
