package citb406s2018week6;

public class Engineer implements Creator {

    private int hourlyWage;

    private int totalHoursWorked;

    private Vehicle listOfVehicles[];

    public Engineer(int hourlyWage, int totalHoursWorked) {
        this.hourlyWage = hourlyWage;
        this.totalHoursWorked = totalHoursWorked;
    }

    public int getHourlyWage() {
        return hourlyWage;
    }

    public void setHourlyWage(int hourlyWage) {
        this.hourlyWage = hourlyWage;
    }

    public int getTotalHoursWorked() {
        return totalHoursWorked;
    }

    public void setTotalHoursWorked(int totalHoursWorked) {
        this.totalHoursWorked = totalHoursWorked;
    }

    @Override
    public double totalEarnings() {
        return hourlyWage * totalHoursWorked;
    }

    public void addVehicle(Vehicle vehicle) {
        System.out.println("Adding vehicle to the array: " + vehicle.toString());
        Vehicle newListOfVehicles[];
        if (listOfVehicles != null) {
            newListOfVehicles = new Vehicle[listOfVehicles.length + 1];
            System.arraycopy(listOfVehicles, 0, newListOfVehicles, 0, listOfVehicles.length);
            newListOfVehicles[newListOfVehicles.length - 1] = vehicle;
        } else {
            newListOfVehicles = new Vehicle[1];
            newListOfVehicles[0] = vehicle;
        }
        listOfVehicles = newListOfVehicles;
    }

    @Override
    public void displayGoods() {
        for (Vehicle vehicle : listOfVehicles) {
            System.out.println(vehicle.toString());
            System.out.println(vehicle.totalCost());
            System.out.println(vehicle.salesPrice());

        }
    }
}
