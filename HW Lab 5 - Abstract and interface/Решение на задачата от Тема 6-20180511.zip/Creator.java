package citb406s2018week6;

public interface Creator {

    public double totalEarnings();
    public void displayGoods();
}
