/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citb406s2018week4;

/**
 *
 * @author Kostadinova
 */
class Program {

    private static int currentCounter = 0;
    private int id;
    private String name;
    private Course requiredCourses[];

    public Program(String name, boolean isMajor) {
        this.id = ++currentCounter;
        this.name = name;
        this.requiredCourses = null;
    }

    public int getId() {
        return id;
    }

    public Course[] getRequieredCourses() {
        return requiredCourses;
    }

    public String getName() {
        return name;
    }

    public Course[] getRequiredCourses() {
        return requiredCourses.clone();
    }

    void addRequiredCourse(Course course) {
        System.out.println("Adding required course: " + course.getName());
        Course newRequiredCourses[];
        if (requiredCourses != null) {
            newRequiredCourses = new Course[requiredCourses.length + 1];
            System.arraycopy(requiredCourses, 0, newRequiredCourses, 0, requiredCourses.length);
            newRequiredCourses[newRequiredCourses.length - 1] = course;
        } else {
            newRequiredCourses = new Course[1];
            newRequiredCourses[0] = course;
        }
        requiredCourses = newRequiredCourses;
    }

    boolean isCourseInProgram(Course course) {
        if (requiredCourses != null) {
            for (Course requiredCourse : requiredCourses) {
                if (requiredCourse.getId() == course.getId()) {
                    return true;
                }
            }
        }
        return false;
    }

    void showRequiredCourses() {
        System.out.println("The required courses " + name + " program are: ");
        if (requiredCourses != null) {
            for (Course courses : requiredCourses) {
                System.out.print(courses.getName() + " ");
            }
        } else {
            System.out.println("There are no required courses in program " + name);
        }
    }

}
