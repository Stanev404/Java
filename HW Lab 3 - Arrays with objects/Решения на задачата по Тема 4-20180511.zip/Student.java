/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citb406s2018week4;

/**
 *
 * @author Kostadinova
 */
class Student {
    private int fNumber;
    private String name;
    private Program majorProgram;
    private Course courseList[];
    private double gradesList[][];
    private boolean isGraduated;

    public Student(int fNumber, String name, Program majorProgram) {
        this.fNumber = fNumber;
        this.name = name;
        this.majorProgram = majorProgram;
        this.courseList = null;
        this.gradesList = null;
        this.isGraduated = false;
    }

    void enrollCourse(Course course) {

        if (majorProgram.isCourseInProgram(course)) {
            System.out.println("Student " + name + " is enrolled in course: " + course.getName());
            Course newCourselist[];
            if (courseList != null) {
                newCourselist = new Course[courseList.length + 1];
                System.arraycopy(courseList, 0, newCourselist, 0, courseList.length);
                newCourselist[newCourselist.length - 1] = course;
            } else {
                newCourselist = new Course[1];
                newCourselist[0] = course;
            }
            courseList = newCourselist;
        } else {
            System.out.println("The course is not in the program!!!");
        }
    }

    void dropCourse(Course course) {
        System.out.println("Dropping course: " + course.getName());
        Course newCourselist[];
        int targetIndex = -1;
        if (courseList != null) {
            for (targetIndex = 0; targetIndex < courseList.length; targetIndex++) {
                if (courseList[targetIndex].getId() == course.getId()) {
                    break;
                }
            }
        }
        if (targetIndex >= 0 && targetIndex < courseList.length) {
            newCourselist = new Course[courseList.length - 1];
            System.arraycopy(courseList, 0, newCourselist, 0, targetIndex);
            System.arraycopy(courseList, targetIndex + 1, newCourselist, targetIndex, courseList.length - targetIndex - 1);
            courseList = newCourselist;
        } else {
            System.out.println("The target is not found!");
        }

    }

    void addGrade(Course course, double grade) {
        if (gradesList != null) {
            double newGradesList[][] = new double[gradesList.length + 1][2];
            System.arraycopy(gradesList, 0, newGradesList, 0, gradesList.length);
            System.out.println("length " + newGradesList.length);
            newGradesList[newGradesList.length - 1][0] = course.getId();
            newGradesList[newGradesList.length - 1][1] = grade;
            gradesList = newGradesList;

        } else {
            gradesList = new double[1][2];
            gradesList[0][0] = course.getId();
            gradesList[0][1] = grade;
        }

        if (isReadyForGraduation()) {
            this.isGraduated = true;
        }
    }

    void showGrades() {
        System.out.println("The grades of " + name + " are: ");
        if (gradesList != null) {
            for (double[] gradesList1 : gradesList) {
                System.out.println((int) gradesList1[0] + " = " + gradesList1[1]);
            }
        } else {
            System.out.println("There are no rades!!!");
        }

    }

    int totalCredits() {
        int sum = 0;
        for (Course courseListN : courseList) {
            sum += courseListN.getNumbeOfCredits();
        }

        return sum;
    }

    boolean areGradesGreaterThan3() {
        if (gradesList != null) {
            for (double[] gradesList1 : gradesList) {
                if (gradesList1[1] < 3) {
                    return false;
                }
            }
        } else {
            System.out.println("There are no grades!!!");
            return false;
        }
        return true;
    }

    boolean isReadyForGraduation() {
        return (areGradesGreaterThan3() && (totalCredits() == 240));
    }

    @Override
    public String toString() {
        return "Student{" + "fNumber=" + fNumber + ", name=" + name + ", majorProgram=" + majorProgram.getName() + ", isGraduated=" + isGraduated + '}';
    }

}
