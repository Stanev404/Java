/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citb406s2018week4;

/**
 *
 * @author Kostadinova
 */
class Course {

    private static int currentCounter = 0;
    private int id;
    private String name;
    private int numbeOfCredits;

    public Course(String name, int numbeOfCredits) {
        id = ++currentCounter;
        this.name = name;
        this.numbeOfCredits = numbeOfCredits;
    }

    public int getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }

    public int getNumbeOfCredits() {
        return numbeOfCredits;
    }

    @Override
    public String toString() {
        return "Course{" + "id=" + id + ", name=" + name + ", numbeOfCredits=" + numbeOfCredits + '}';
    }

}
