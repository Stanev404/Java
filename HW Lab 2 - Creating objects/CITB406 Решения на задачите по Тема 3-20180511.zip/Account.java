/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citb406S2018week3;

/**
 *
 * @author Kostadinova
 */
public class Account {

    private int accountNumber;
    private double accountBalance;
    private static double interestRate = 5;

    public Account(int account_number) {
        this.accountNumber = account_number;
        this.accountBalance = 0;
    }

    public void showData() {
        System.out.println("Account number is: " + accountNumber);
        System.out.println("Account balance is: " + accountBalance);
        System.out.println("Interest rate is: " + Account.interestRate);
    }

    public void deposit(double amountOfMoney) {
        if (amountOfMoney < 0) {
            System.out.println("You cannot deposit negative number of money");
        } else {
            this.accountBalance += amountOfMoney;
        }
    }

    public void accumulation() {
        this.accountBalance += this.accountBalance * (Account.interestRate / 100);
    }

    public void setAccount_number(int account_number) {
        this.accountNumber = account_number;
    }

    public static void setInterestRate(double interestRatePercentage) {
        Account.interestRate = interestRatePercentage;
    }

}
