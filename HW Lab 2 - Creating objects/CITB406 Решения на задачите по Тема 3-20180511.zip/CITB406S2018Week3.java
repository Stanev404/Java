/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citb406S2018week3;

/**
 *
 * @author Kostadinova
 */
public class CITB406S2018Week3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        {
            Town sofia = new Town();
            sofia.showData();
            int f = 9;
            double area = 14.2;
            sofia.increaseArea(area);
            sofia.showData();
            int numberOfPeople = 3420;
            sofia.increasePopulation(numberOfPeople);
            sofia.showData();
            numberOfPeople = 220;
            sofia.decrerasePopulation(numberOfPeople);
            sofia.showData();
        }

        {
            int accountNumber = 12243232;
            Account account1 = new Account(accountNumber);
            account1.showData();
            double interestRate = 5.5;
            double amountOfMoney = 1000;
            Account.setInterestRate(interestRate);
            account1.deposit(amountOfMoney);
            account1.showData();
            account1.accumulation();
            account1.showData();

        }

        {
            FlowersShop flowersShop1 = new FlowersShop(100, 8);
            flowersShop1.showFlowersShop();
            int numberOfFlowers = 30;
            double price = 2;
            flowersShop1.decreraseNumberOfFlowers(numberOfFlowers);
            flowersShop1.decreasePrice(price);
            flowersShop1.showFlowersShop();
            flowersShop1.increaseNumberOfFlowers(124);
            flowersShop1.increasePrice(5);
            flowersShop1.showFlowersShop();
        }

        {
            Triangle triangle1 = new Triangle(3, 4, 5);
            Triangle triangle2 = new Triangle(9);
            Triangle triangle3 = new Triangle();
            System.out.println("istr " + triangle1.perimeter());
            int number = 1;
            System.out.println(triangle1.area());
            triangle1.display_triangle();
            triangle1.increaseSideLength(number);
            System.out.println(triangle1.isEquilateral());
            System.out.println(triangle1.isRectangular());
            System.out.println(triangle1.isTriangle());
            System.out.println(triangle1.perimeter());
            triangle1.display_triangle();
        }

    }

}
