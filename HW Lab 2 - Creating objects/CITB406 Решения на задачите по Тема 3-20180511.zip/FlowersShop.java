/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citb406S2018week3;

/**
 *
 * @author Kostadinova
 */
public class FlowersShop {

    private int numberOfFlowers;
    private double pricePerFlower;

    public FlowersShop() {
        this.numberOfFlowers = 0;
        this.pricePerFlower = 0;
    }

    public FlowersShop(int numberOfFlowers) {
        this.numberOfFlowers = numberOfFlowers;
        this.pricePerFlower = 0;
    }

    public FlowersShop(double pricePerFlower) {
        this.numberOfFlowers = 0;
        this.pricePerFlower = pricePerFlower;
    }

    public FlowersShop(int numberOfFlowers, double pricePerFlower) {
        this.numberOfFlowers = numberOfFlowers;
        this.pricePerFlower = pricePerFlower;
    }

    public void increaseNumberOfFlowers(int numberOfFlowers) {
        if (numberOfFlowers < 0) {
            System.out.println("You cannot increase number of flowers with negative number!");
        } else {
            this.numberOfFlowers += numberOfFlowers;
        }
    }

    public void decreraseNumberOfFlowers(int numberOfFlowers) {
        if (numberOfFlowers < 0) {
            System.out.println("You cannot decrease number of flowers with negative number!");
        } else if (this.numberOfFlowers <= numberOfFlowers) {
            this.numberOfFlowers = 0;
        } else {
            this.numberOfFlowers -= numberOfFlowers;
        }
    }

    public void increasePrice(double pricePerFlower) {
        if (pricePerFlower < 0) {
            System.out.println("You cannot increase price of flower with negative number!");
        } else {
            this.pricePerFlower += pricePerFlower;
        }
    }

    public void decreasePrice(double pricePerFlower) {
        if (pricePerFlower < 0) {
            System.out.println("You cannot decrease price of flower with negative number!");
        } else if (this.pricePerFlower <= pricePerFlower) {
            this.pricePerFlower = 0;
        } else {
            this.pricePerFlower -= pricePerFlower;
        }
    }

    double revenue() {
        return numberOfFlowers * pricePerFlower;
    }

    public void showFlowersShop() {
        System.out.println("The number of flowers is: " + numberOfFlowers);
        System.out.println("The price of one flower is: " + pricePerFlower);
        System.out.println("The total revenue is: " + revenue());
    }

}
