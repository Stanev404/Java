package citb406s2018week5;

public class Building {

    protected double area;

    public Building(double area) {
        this.area = area;
    }

    public double getArea() {
        return area;
    }

    public void printCapacity() {
        System.out.print("The capacity of the building is: ");
        System.out.println(" area = " + area);

    }

}
