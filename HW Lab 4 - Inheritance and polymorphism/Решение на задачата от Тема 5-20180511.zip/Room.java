package citb406s2018week5;

public class Room extends Premise {

    private int numberOfBeds;

    public Room(int numberOfBeds, double area) {
        super(area);
        this.numberOfBeds = numberOfBeds;
    }

    public int getNumberOfBeds() {
        return numberOfBeds;
    }

    @Override
    public void printCapacity() {
        super.printCapacity();
        System.out.println(" number of beds = " + numberOfBeds);

    }
}
