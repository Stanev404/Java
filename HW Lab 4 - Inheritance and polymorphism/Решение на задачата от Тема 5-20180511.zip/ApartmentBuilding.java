package citb406s2018week5;

public class ApartmentBuilding extends Building {

    private int numberOfApartments;

    private Apartment listOfApartments[];

    public ApartmentBuilding(int numberOfApartments, double area) {
        super(area);
        this.numberOfApartments = numberOfApartments;
        listOfApartments = new Apartment[numberOfApartments];
    }

    public int getNumberOfApartments() {
        return numberOfApartments;
    }

    public Apartment[] getListOfApartments() {
        return listOfApartments.clone();
    }

    @Override
    public void printCapacity() {
        super.printCapacity();
        System.out.println(" number of apartments = " + numberOfApartments);

    }
}
