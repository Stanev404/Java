package citb406s2018week5;

public class BusinessBuilding extends Building {

    private int numberOfOffices;

    private Office listOfOffices[];

    public BusinessBuilding(int numberOfOffices, double area) {
        super(area);
        this.numberOfOffices = numberOfOffices;
        listOfOffices = new Office[numberOfOffices];
    }

    public int getNumberOfOffices() {
        return numberOfOffices;
    }

    public Office[] getListOfOffices() {
        return listOfOffices.clone();
    }

    @Override
    public void printCapacity() {
        super.printCapacity();
        System.out.println(" number of apartments = " + numberOfOffices);
    }
}
