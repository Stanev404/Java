package citb406s2018week5;

public class Office extends Premise {

    private int numberOfWorkPlaces;

    public Office(int numberOfWorkPlaces, double area) {
        super(area);
        this.numberOfWorkPlaces = numberOfWorkPlaces;
    }

    public int getNumberOfWorkPlaces() {
        return numberOfWorkPlaces;
    }

    @Override
    public void printCapacity() {
        super.printCapacity();
        System.out.println(" number of workplaces = " + numberOfWorkPlaces);

    }
}
