package citb406s2018week5;

public class Premise {

    protected double area;

    public Premise(double area) {
        this.area = area;
    }

    public double getArea() {
        return area;
    }

    public void printCapacity() {
        System.out.print("The capacity of the premise is: ");
        System.out.println(" area = " + area);
    }
}
