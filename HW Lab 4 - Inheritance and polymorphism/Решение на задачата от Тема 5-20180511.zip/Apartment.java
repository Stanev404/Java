package citb406s2018week5;

public class Apartment extends Premise {

    private int numberOfTerraces;

    public Apartment(int numberOfTerraces, double area) {
        super(area);
        this.numberOfTerraces = numberOfTerraces;
    }

    public int getNumberOfTerraces() {
        return numberOfTerraces;
    }

    @Override
    public void printCapacity() {
        super.printCapacity();
        System.out.println(" number of terraces = " + numberOfTerraces);

    }
}
