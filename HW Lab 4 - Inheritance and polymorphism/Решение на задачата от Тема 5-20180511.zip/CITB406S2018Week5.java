/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citb406s2018week5;

/**
 *
 * @author Kostadinova
 */
public class CITB406S2018Week5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        {
            Figure f = new Figure(10, 10);
            Rectangle r = new Rectangle(9, 5);
            Triangle t = new Triangle(10, 8);
            Figure figref;
            figref = r;
            System.out.println("Area is " + figref.area());
            figref = t;
            System.out.println("Area is " + figref.area());
            figref = f;
            System.out.println("Area is " + figref.area());

            int numbeOfFigures = 10;
            Figure[] arrayOfFigures;
            arrayOfFigures = new Figure[numbeOfFigures];
            int i = 10;
            for (int counter = 0; counter < numbeOfFigures / 2; counter++) {
                arrayOfFigures[counter] = new Triangle(++i, i + 2);
            }
            for (int counter = numbeOfFigures / 2; counter < numbeOfFigures; counter++) {
                arrayOfFigures[counter] = new Rectangle(++i, i + 2);
            }
            for (int counter = 0; counter < numbeOfFigures; counter++) {
                System.out.println(arrayOfFigures[counter].area());
            }
        }

        {
            Premise arrayOfPremises[] = new Premise[10];
            for (int counter = 0; counter < arrayOfPremises.length / 2; counter++) {
                arrayOfPremises[counter] = new Apartment(2, 90);
            }
            for (int counter = arrayOfPremises.length / 2; counter < arrayOfPremises.length; counter++) {
                arrayOfPremises[counter] = new Room(3, 30);
            }
            for (Premise arrayOfPremise : arrayOfPremises) {
                arrayOfPremise.printCapacity();
            }

            Building arrayOfBuildings[] = new Building[10];
            for (int counter = 0; counter < arrayOfBuildings.length / 2; counter++) {
                arrayOfBuildings[counter] = new ApartmentBuilding(9, 150);
            }
            for (int counter = arrayOfBuildings.length / 2; counter < arrayOfBuildings.length; counter++) {
                arrayOfBuildings[counter] = new BusinessBuilding(30, 124);
            }
            for (Building arrayOfBuilding : arrayOfBuildings) {
                arrayOfBuilding.printCapacity();
            }

        }
    }

}
